# PRODIGY_DS_02
Acquired as a Data Science Intern @Prodigy Infotech Company: July- August 2023

Performed Data Cleaning and Exploratory Data Analysis on the given dataset.
